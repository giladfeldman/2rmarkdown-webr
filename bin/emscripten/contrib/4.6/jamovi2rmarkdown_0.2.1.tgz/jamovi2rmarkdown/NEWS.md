# jamovi2rmarkdown 0.2.1

## Documentation (2026-09-27)

* README rewritten from the source: every exported function (including
  `process_single_file()`, previously undocumented), the pipeline, what is converted (any
  stored jmv call; the base-R one-sample TOST; the computed-variable formula functions that
  are translated), the required `jmvReadWrite` and `RProtoBuf` dependencies, output files,
  the `HOME` environment variable, limitations, citation and contributing.
* Stale claims fixed: the README Quick Start, the vignette and the `generate_rmd()` example
  called `reconstruct_data_code()`, which is not exported; the vignette listed
  `jmv::logReg` (the function is `jmv::logRegBin`); `process_single_file()` was documented as
  returning `status` (it returns `success`).
* Added `CITATION.cff` and `CONTRIBUTING.md`.
* `tools/check_docs_coverage.R` fails when an export, environment variable or option is missing
  from the README, when versions disagree, or when the README Quickstart does not run;
  `tests/testthat/test-docs-coverage.R` pins it two-sided.

Packaging and documentation corrections only — no change to generated output
or to any computed value.

* `withr` and `TOSTER` are declared in Suggests. Both are used by the test
  suite but were undeclared, so a clean install could fail to run the tests.
* `MASS` moved from Imports to Suggests (it is only needed on one code path),
  and `switch()`'s `EXPR` argument is named, clearing `R CMD check` warnings.
* Documented why `get_session_output_dir` appears as an undefined global.

# jamovi2rmarkdown 0.2.0

First publish since 2026-03-29 — this release carries ~33 commits of fixes
developed in the app repo since 0.1.1. Highlights:

## Numeric correctness

* Non-1-based labelled factors preserve their true codes (fixes a +1-offset bug
  that silently shifted every level).
* jamovi `MEAN`/`SUM`/`MIN`/`MAX` follow strict missing-value semantics rather
  than dropping NAs implicitly.
* TRUE/FALSE-labelled columns keep their underlying 1/2 numeric encoding.
* Row-filters that compare a labelled factor to a numeric code now apply.
* Per-analysis filter routing: analyses declared before a filter use the
  unfiltered data, later ones use the filtered data — order changes N silently.
* `TOSTER::dataTOSTone` one-sample TOST reproduced in base R, GT-exact.
* t-test CI columns (`meanDiff` + `ci`) and ordinal frequency tables.

## Robustness

* Formula tokenizer is backtick- and quote-aware: commas and spaces inside
  column names no longer split an argument list mid-name.
* Numeric coercion for PCA/EFA/ANOVA/descriptives, RM-ANOVA `rmCells`, t-test
  vars, and grouped-descriptives formula LHS (the `var-factor` route is defunct).
* Module-call arguments reconciled against the installed function version;
  render-time module install with `gamlj` casing normalised and a visible note
  when a module is unavailable.
* `jmv` tables flagged `visible=FALSE` are skipped (empty Levene/Shapiro shells).
* `.res` resets before each analysis block; degenerate analyses dropped;
  null/NA-safe `corrMatrix` flag formatting; `MASS` ensured for `corrPart`.
* Unsafe computed-column target names emit a NOTE instead of invalid R.

## Output

* Analysis tables render as real HTML (fixes Unicode box-drawing mojibake),
  with a floating TOC and code folding.
* `R CMD check --as-cran` WARNINGs cleared.

# jamovi2rmarkdown 0.1.1

* Gate generated computed-column target identifiers (cross-project rec R-0009,
  ported from STATA2Rmarkdown's `is_valid_r_ident()`). A computed-column name
  that is empty or itself contains a backtick cannot be safely backtick-quoted;
  emitting it was a parse error that broke the entire shared `dplyr::mutate()`
  and silently dropped EVERY computed column. Such names now become a
  `# NOTE [JAMOVI]` comment and the remaining columns still reconstruct.
* Also includes earlier fixes since 0.1.0: quote-aware formula argument
  splitting (string-literal commas no longer mis-split `IF()`/`RECODE()` args);
  apply row filters that compare a labelled factor to its numeric code; coerce
  numeric-coded variables for PCA/EFA/ANOVA/descriptives.

# jamovi2rmarkdown 0.1.0

* Initial release
* Parse .omv files and extract analyses
* Generate R Markdown reports with jmv function calls
* Support for descriptives, t-tests, ANOVA, correlation, regression, reliability
