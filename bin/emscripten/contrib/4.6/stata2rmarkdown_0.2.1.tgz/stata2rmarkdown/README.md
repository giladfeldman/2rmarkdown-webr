# stata2rmarkdown

Convert Stata `.do` files into reproducible R Markdown reports.

The converter parses a do-file (comments, `///` continuations, `#delimit`, local and global
macros, `foreach`/`forvalues` loops), translates each command into R — estimation mostly with
[`fixest`](https://cran.r-project.org/package=fixest), tables with `modelsummary`, data
management with `dplyr`/`tidyr` — and writes an `.Rmd` that keeps the original Stata syntax
beside every block. It is deterministic: the same do-file always produces the same R code.
Designed for replicating published economics and finance analyses without a Stata licence.

Part of a family of converters with a shared design: `spss2rmarkdown`, `jamovi2rmarkdown`,
`jasp2rmarkdown` and the shared-core package `stat2rmarkdown` (all at
<https://github.com/giladfeldman>).

Version 0.2.1 · MIT licence · R >= 4.1.0

**Principle: the converter converts the syntax, it does not repair it.** If Stata itself would
stop on a command (a missing data file, say), the report says so at that point instead of
running something else.

## Installation

```r
# install.packages("remotes")
remotes::install_github("giladfeldman/stata2rmarkdown")
```

Imports: `haven`, `dplyr`, `glue`, `stringr`, `rmarkdown`. To **knit** the reports you also need
pandoc and the packages the do-file's commands translate to — most often:

```r
install.packages(c("fixest", "modelsummary", "tidyr", "ggplot2", "janitor", "car",
                   "marginaleffects", "sandwich", "lmtest", "AER", "MASS"))
# as needed: plm, lme4, nnet, urca, vars, moments, skedastic
```

## Quickstart

Write a small do-file and dataset, convert, and knit (`convert_do_to_rmd()` renders the HTML
itself unless `render_html = FALSE`):

```r
library(stata2rmarkdown)

work <- file.path(tempdir(), "stata2r-demo")
dir.create(work, showWarnings = FALSE)
haven::write_dta(mtcars, file.path(work, "cars.dta"))
writeLines(c(
  "* demo do-file",
  "gen heavy = wt > 3",
  "summarize mpg wt",
  "regress mpg wt hp, robust",
  "eststo m1",
  "ttest mpg, by(am)",
  "esttab m1"
), file.path(work, "demo.do"))

res <- convert_do_to_rmd(
  file.path(work, "demo.do"),
  dta_path    = file.path(work, "cars.dta"),
  output_dir  = file.path(work, "out"),
  render_html = rmarkdown::pandoc_available()
)
cat("Converted", res$coverage, "% of commands ->", res$rmd_path, "\n")
if (!is.null(res$html_path)) cat("Report:", res$html_path, "\n")

convert_stata_expr("ln(income) if age >= 18 & !missing(educ)")
```

## How it works

```
.do ──parse_do()──► commands (macros expanded) ──convert_all_commands()──► R blocks ──generate_rmd()──► .Rmd ──► .html
.dta ──parse_dta()──► data + labels ─────────────┘
```

- **Parsing** removes `*`, `//` and `/* */` comments, joins `///` continuations, honours
  `#delimit ;`, expands `local`/`global` macros and unrolls `foreach`/`forvalues`, then splits
  each command into the Stata anatomy `[prefix:] command [varlist] [=exp] [if] [in]
  [using] [, options]`.
- **Every generated block is wrapped in `tryCatch()`**, so one failing command is reported in
  place and the rest of the report still knits.
- **Missing data stops downstream analyses**, as Stata's `r(601)` would, with a note naming the
  file that could not be loaded.

The full command list — what each Stata command becomes in R, which commands produce only a
template, and which are skipped — is in [`docs/commands.md`](docs/commands.md).

## Function reference

Every function has a help page (`?convert_do_to_rmd`).

| Function | What it does |
|---|---|
| `convert_do_to_rmd(do_path, dta_path = NULL, output_dir = NULL, base_name = NULL, include_original = TRUE, match_stata_se = TRUE, render_html = TRUE)` | The whole pipeline. `output_dir` defaults to `output/<timestamp>-<base_name>`. With `dta_path`, writes `<base_name>.rds` (loaded by the report) and `<base_name>_data.csv`. Returns `rmd_path`, `html_path` (`NULL` if not rendered), `data_path`, `parsed`, `converted` and `coverage` (see Limitations for what it counts). `include_original = FALSE` drops the Stata syntax from the report. `match_stata_se` is accepted but currently has no effect: robust standard errors always use HC1. |
| `parse_do(do_path)` | Reads and parses a do-file (see How it works). Returns a list of commands, each with `command_type`, `raw`, `body`, `variables`, `options`, `if_qualifier`, `in_qualifier`, `using` and `prefix`. |
| `parse_single_stata_command(cmd_text)` | Parses one command string into the same structure. |
| `expand_macros(lines)` | Expands `local`/`global` macros and unrolls `foreach`/`forvalues` in a character vector of cleaned lines. |
| `parse_dta(dta_path)` | Reads a `.dta` with `haven`. Returns `data`, `metadata`, `value_labels`, `dataset_label`, `n_obs`, `n_vars`, `path`. |
| `convert_all_commands(parsed_commands, dta_info = NULL)` | Converts every parsed command, carrying state between them (`xtset` panel variables, stored `eststo` models). Returns one list per command with `r_code`, `packages`, `analysis_type`, `is_transformation`, and `skip` for skipped commands. |
| `convert_stata_to_r(parsed_command, dta_info = NULL)` | Converts one parsed command (same return shape). |
| `convert_stata_expr(expr, glue_fragments = TRUE)` | Translates a Stata expression: operators (`~=`, `!=`, `&`, `\|`), functions (`ln()` to `log()`, `missing()` to `is.na()`, `inlist()`, `inrange()`, ...), `_n`/`_N`, and `==.` / `!=.` missing tests. `glue_fragments` applies Stata's rule that whitespace-separated name fragments inside parentheses join into one name. |
| `generate_rmd(dta_data, dta_path, parsed_syntax, converted_code, output_dir, options = list(), base_name = NULL, conversion_notes = list())` | Writes `<base_name>.Rmd` and returns `rmd_path` and `data_path`. `options$include_original` (default `TRUE`) keeps the Stata syntax; `conversion_notes` (each with `level` and `message`) are listed in a "Conversion Notes" table. |
| `create_output_dir(base_name, output_root = "output")` | Creates `output_root/<timestamp>-<base_name>` and returns its path. |
| `%>%` | The `dplyr`/`magrittr` pipe, re-exported because the generated code uses it. |

## Output

`convert_do_to_rmd()` writes into `output_dir`: `<base_name>.Rmd`, `<base_name>.html` (when
rendered), and with a `.dta` also `<base_name>.rds` and `<base_name>_data.csv`. The HTML is a
single self-contained file with a floating table of contents and folded code; each block shows
the Stata syntax, then the R result (regression tables via `summary()` / `modelsummary`).

## Configuration

| Environment variable | Read when | Effect |
|---|---|---|
| `STATA_BUILTIN_DIR` | knitting a generated report | Folder of `<name>.rds` copies of Stata's example datasets. A `use` of `<name>.dta` loads the `.rds` from there when one exists, then falls back to `./builtin-datasets`, `../builtin-datasets`, and finally the real `.dta`. The package does not ship these copies. |

No `options()` are read. `inst/extdata/command_registry.csv` is a reference table of Stata
commands and their R counterparts; the converter does not read it.

## Limitations and failure modes

- **Check every number against the Stata log before relying on it.** The converter is tested
  against Stata output for the models in its test suite, but a do-file can use options it has
  not been tested with.
- **`xtreg` without `fe` or `re` is fitted as fixed effects**, although Stata's default is
  random effects; `be`, `mle` and `pa` are also fitted as fixed effects. Add `, fe` or `, re`
  explicitly to get the estimator you mean.
- **`signrank x = y` is translated as a one-sample test of `x` against 0**; the comparison
  variable is dropped, so the result is not Stata's paired signed-rank test.
- **`ivreg` and `xtivreg` without an estimator keyword** (`ivreg y (x = z)`) produce a
  "no dependent variable" note instead of a model; `ivregress 2sls ...` converts.
- **`sysuse` and `webuse` are skipped**: pass the dataset as `dta_path`, or set
  `STATA_BUILTIN_DIR`.
- **Commands listed as "template only" in `docs/commands.md` compute nothing**, but
  `coverage` counts them as converted — it measures commands that were not skipped or
  unsupported, not commands that produce a result.
- Several skipped commands change the data in Stata (`joinby`, `cross`, `fillin`, `import`,
  `input`, ...): see `docs/commands.md`.
- `do` / `run` / `include` do not follow into the called file; convert it separately.
- The one-letter abbreviation `g` for `generate` is not recognised (it produces a note);
  `gen` and `generate` work.
- Stata graphs are approximated with `ggplot2` where a translation exists; graph styling is
  not reproduced.

## Keeping this README honest

`tools/check_docs_coverage.R` derives the public surface from the package source (every
`export()` in `NAMESPACE`, every environment variable and option the code reads, and — via
`tools/docs_surface_extra.R` — every Stata command the converter dispatches on or skips) and
fails if any of it is missing from this README or `docs/`, if `DESCRIPTION`, `NEWS.md` and
`CITATION.cff` disagree on the version, or if the Quickstart does not run:

```sh
Rscript tools/check_docs_coverage.R            # from the package root
Rscript tools/check_docs_coverage.R --no-run   # skip executing the Quickstart
```

`tests/testthat/test-docs-coverage.R` pins it both ways when the tests run from a source
checkout (`testthat::test_local()`).

## How to cite

See [`CITATION.cff`](CITATION.cff):

> Feldman, G. (2026). *stata2rmarkdown: Convert Stata do-files to reproducible R Markdown
> reports* (Version 0.2.1) [R package]. https://github.com/giladfeldman/stata2rmarkdown

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md). Issues: <https://github.com/giladfeldman/stata2rmarkdown/issues>.

## License

MIT — see [`LICENSE.md`](LICENSE.md).
