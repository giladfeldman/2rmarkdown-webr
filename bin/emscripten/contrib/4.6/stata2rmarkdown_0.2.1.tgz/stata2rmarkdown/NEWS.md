# stata2rmarkdown 0.2.1

## Documentation (2026-09-27)

* README rewritten from the source, with a new `docs/commands.md` listing every Stata command
  the converter handles and what the generated R does with it (each row produced by running
  the command through the converter), which commands only produce a template, and which are
  skipped. Documents every export, the `STATA_BUILTIN_DIR` environment variable, output
  files and limitations; adds a Quickstart that converts and knits.
* Stale claims fixed: the install line used a `subdir` that does not exist in this repository;
  `match_stata_se` was documented as switching robust standard errors to HC1 (they are always
  HC1; the argument has no effect); the "55+ commands" and coverage figures were replaced by
  the full derived list.
* Newly documented limitations found while probing: `xtreg` without `fe`/`re` is fitted as
  fixed effects (Stata's default is random effects); `signrank x = y` drops the comparison
  variable; `ivreg`/`xtivreg` without an estimator keyword produce no model; `coverage`
  counts template-only conversions as converted.
* Removed internal file references from this NEWS file, a code comment, a test comment, and
  a comment that was emitted into every generated report.
* Added `CITATION.cff` and `CONTRIBUTING.md`.
* `tools/check_docs_coverage.R` (with `tools/docs_surface_extra.R` deriving the command list)
  fails when an export, environment variable, option or Stata command is missing from the
  docs, when versions disagree, or when the Quickstart does not run;
  `tests/testthat/test-docs-coverage.R` pins it two-sided.

- Stata expression-lexer parity: whitespace-separated name fragments inside
  parenthesized RHS subexpressions now glue into one identifier, as real Stata
  does (`(cd_ed_ con _1 -1)/6` == `(cd_ed_con_1 -1)/6`; verified Stata 19+14).
  Scoped precisely: no gluing at expression top level, in `if` qualifiers,
  varlists, factor/time-series operands, or the LHS — real Stata errors there
  (r(198)), and so does the generated R.

# stata2rmarkdown 0.2.0

First publish since 2026-03-29 — this release carries ~35 commits of fixes
developed in the app repo since 0.1.0. Highlights:

## Numeric correctness

* `ttest x, by(g)` now defaults to `var.equal = TRUE`, matching Stata's pooled
  default rather than R's Welch default — a silent cross-language trap.
* `correlate` honours `if` filters and listwise deletion; `bysort`-relative
  `_n`/`_N`; `logit` binarises its outcome; `expand` implemented.
* `==.` / `!=.` missing-comparisons translate to `is.na()` rather than
  comparing against a literal.
* `predict` residuals for `fixest::feols` no longer come back all-NA.
* `encode`/`recode` `gen()` options, `r()` saved results, and a base-R
  `pwcorr` — the CSI multi-covariate model now reproduces Stata exactly.
* `recode` handles multi-value lists (e.g. `-9 -8 -1 = .`).

## Coverage

* Time-series engine: `varsoc`, `dfuller`, `pperron`, `var`, `irf`.
* Observation subscripting `var[_n±k]` maps to lag/lead.
* Stata date functions (`tm`/`tq`/`tw`/`th`/`ty`/`td` and the `mofd` family).
* Varlists and wildcards translate to valid R in `select`/`egen`/`rename`/`reshape`.
* `xtreg` consumes the `xtset` panel var and emits `plm` with `index=`.
* Mixed models, abbreviated label commands, `grstyle`.
* `split`, nested global-macro paths, multi-expression `display`.

## Output and robustness

* Analysis tables render as real HTML (fixes Unicode box-drawing mojibake),
  with a floating TOC and code folding.
* Per-`use` scoping: each `use` resets `data` and analyses follow in source order.
* Per-scope missing-data and `cd`-target guards; Windows paths emitted as R raw
  strings; weight specs stripped before parsing; string-aware `if`/`in`/`using`
  splitting; block-comment and macro-residue defenses.
* Generated reports link to the correct repository (was a `your-repo`
  placeholder — caught by the new publish guard).
* `R CMD check --as-cran` WARNINGs cleared.

# stata2rmarkdown 0.1.0

* Initial release
* Parse Stata .do files with 55+ command support
* Convert Stata commands to R using fixest + modelsummary + tidyverse
* Expression converter for Stata -> R syntax
* Macro expansion (local, global, foreach, forvalues)
* Generate reproducible R Markdown reports
* 95.9% command coverage across 237 real .do files
* Validated against Stata MP 19.5 -- exact numerical match
