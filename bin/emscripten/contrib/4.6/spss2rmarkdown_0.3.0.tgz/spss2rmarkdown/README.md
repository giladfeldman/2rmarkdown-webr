# spss2rmarkdown

Convert SPSS `.sps` syntax files and `.sav` data files into reproducible R Markdown reports.

The package reads an SPSS syntax file, translates each command into equivalent R code (mostly
calls to the [`jmv`](https://cran.r-project.org/package=jmv) package, the statistical engine
behind jamovi, plus `dplyr` for data transformations), and writes a self-contained `.Rmd` that
loads the `.sav`, runs every transformation and analysis, and keeps the original SPSS syntax
beside each result. Knitting that `.Rmd` re-runs the analysis in R, so a reader can check a
published SPSS analysis without an SPSS licence.

Part of a family of converters with a shared design: `jamovi2rmarkdown`, `jasp2rmarkdown`,
`stata2rmarkdown` and the shared-core package `stat2rmarkdown` (all at
<https://github.com/giladfeldman>).

Version 0.3.0 · MIT licence · R >= 4.1.0

**Principle: the converter converts the syntax, it does not repair it.** If SPSS itself would
fail on a command (an undefined variable, say), the generated report shows that failure rather
than silently substituting something that runs.

## Installation

```r
# install.packages("remotes")
remotes::install_github("giladfeldman/spss2rmarkdown")
```

Imports: `haven`, `dplyr`, `glue`, `stringr`, `jsonlite`. To **knit** the generated reports
you also need `rmarkdown` (and pandoc), `jmv`, and — depending on the commands in your
syntax — `psych` (FACTOR), `ppcor` (PARTIAL CORR), `olsrr` (stepwise REGRESSION),
`lubridate` (date functions), `tidyr`, `ggplot2`. All are listed under Suggests:

```r
install.packages(c("rmarkdown", "jmv", "psych", "ppcor", "olsrr", "lubridate"))
```

## Quickstart

The package ships a small example study (a `.sps` and its `.sav`). This converts it and knits
the report:

```r
library(spss2rmarkdown)

sps <- system.file("testdata", "Normality-experiment-1-syntax.sps", package = "spss2rmarkdown")
sav <- system.file("testdata", "Normality-experiment-1-data.sav", package = "spss2rmarkdown")

parsed    <- parse_sps(sps)                        # 1. parse the syntax
sav_info  <- parse_sav(sav)                        # 2. read the data + metadata
converted <- convert_all_commands(parsed, sav_info)  # 3. translate every command

out_dir <- file.path(tempdir(), "spss2r-demo")
dir.create(out_dir, showWarnings = FALSE)
file.copy(sav, out_dir, overwrite = TRUE)          # the .Rmd reads the .sav from its own folder

rmd <- generate_rmd(                               # 4. write the .Rmd
  sav_data       = sav_info,
  sav_path       = sav,
  parsed_syntax  = parsed,
  converted_code = converted,
  output_dir     = out_dir,
  base_name      = "normality-demo"
)
cat(length(parsed), "commands parsed;", rmd$rmd_path, "\n")

if (rmarkdown::pandoc_available()) {               # 5. knit it (needs rmarkdown + jmv)
  html <- rmarkdown::render(rmd$rmd_path, quiet = TRUE)
  cat("Report:", html, "\n")
}
```

## How it works

```
.sps ──parse_sps()──► parsed commands ─┐
                                        ├─convert_all_commands()──► R code blocks ──generate_rmd()──► .Rmd
.sav ──parse_sav()──► data + metadata ─┘                                                              │
                                                                                     rmarkdown::render() ▼
                                                                                                     .html
```

- **Parsing** strips comments, splits commands on the SPSS terminating period, recognises full
  and abbreviated command names, and records each command's subcommands, variables and options.
  It also tracks the active `FILTER` (so each analysis runs on the rows SPSS would use) and the
  active dataset (`GET FILE` / `DATASET ACTIVATE`).
- **Variable names** are upper-cased (SPSS is case-insensitive); `var1 TO var5` ranges are
  expanded against the dataset's column order; 8-character-truncated legacy names are matched
  back to the full `.sav` name when the match is unique.
- **Every generated command is wrapped in `tryCatch()`**, so one failing analysis is reported in
  place and the rest of the report still knits.

## Supported SPSS commands

### Analyses

| SPSS command | R engine in the generated code |
|---|---|
| `DESCRIPTIVES`, `FREQUENCIES`, `MEANS`, `EXAMINE` | `jmv::descriptives` |
| `CORRELATIONS` | `jmv::corrMatrix` |
| `PARTIAL CORR` | `ppcor::pcor.test` (and `jmv::corrMatrix`) |
| `T-TEST` (independent, paired, one-sample; `GROUPS=g(v1 v2)` subsets to the listed values) | `jmv::ttestIS` / `jmv::ttestPS` / `jmv::ttestOneS` |
| `ONEWAY` | `jmv::anovaOneW` / `jmv::ANOVA` |
| `GLM`, `UNIANOVA`, `ANOVA` (between, with covariates, repeated measures) | `jmv::ANOVA` / `jmv::ancova` / `jmv::anovaRM` |
| `MANOVA` | `jmv::mancova` |
| `REGRESSION` (hierarchical `/METHOD` blocks; `STEPWISE`/`FORWARD`/`BACKWARD`) | `jmv::linReg`; stepwise via `olsrr` |
| `LOGISTIC REGRESSION` | `jmv::logRegBin` |
| `CROSSTABS` | `jmv::contTables` |
| `RELIABILITY` | `jmv::reliability` (Cronbach's alpha only — McDonald's omega is not reported, matching SPSS `MODEL=ALPHA`) |
| `FACTOR` | `psych::principal`, with `psych::KMO` and `psych::cortest.bartlett` |
| `NPAR TESTS` `/M-W`, `/WILCOXON`, `/K-W` | `jmv::ttestIS`, `jmv::ttestPS`, `jmv::anovaOneW` (non-parametric options) |
| `NPAR TESTS` `/CHISQUARE`, `/K-S`, `/BINOMIAL`, `/FRIEDMAN`, `/SIGN`, `/RUNS`, `/MEDIAN` | base R: `chisq.test`, `ks.test` (normal with the sample mean and SD), `binom.test`, `friedman.test`, a sign test via `binom.test`, a normal-approximation runs test, a median test via `chisq.test` |
| `ROC` | base R: AUC from the Mann-Whitney U statistic, plus an ROC curve |
| `QUICK CLUSTER` | `stats::kmeans` on standardised variables (see Limitations) |

### Data transformations

`COMPUTE`, `RECODE` (including `INTO`), `IF`, `COUNT`, `SELECT IF`, `FILTER BY` / `FILTER OFF`
/ `USE ALL`, `SORT CASES`, `SPLIT FILE`, `DELETE VARIABLES`, `AGGREGATE`, `RANK`,
`MISSING VALUES` (user-missing codes become `NA`), `EXECUTE`.

### Expressions

`convert_spss_expression()` translates SPSS operators and these functions:

| SPSS | R |
|---|---|
| `AND`, `OR`, `NOT`, `&`, `\|`, `~` | `&`, `\|`, `!` |
| `=`, `EQ`, `<>`, `~=`, `NE`, `GE`, `GT`, `LE`, `LT` | `==`, `!=`, `>=`, `>`, `<=`, `<` |
| `**` | `^` |
| `MEAN(a, b)`, `MEAN.n(a, b, ...)` | `rowMeans(cbind(...), na.rm = TRUE)` (with the `.n` minimum-valid rule) |
| `SUM`, `MIN`, `MAX` | `rowSums(..., na.rm = TRUE)`, `pmin`, `pmax` |
| `NVALID`, `NMISS`, `MISSING`, `SYSMIS` | `rowSums(!is.na(...))`, `rowSums(is.na(...))`, `is.na` |
| `ANY(x, v1, v2)`, `RANGE(x, lo, hi)` | `x %in% c(...)`, `dplyr::between` |
| `ABS`, `SQRT`, `LN`, `LG10`, `EXP`, `RND`, `TRUNC` | `abs`, `sqrt`, `log`, `log10`, `exp`, `round`, `trunc` |
| `DATEDIFF(d1, d2, unit)` | `lubridate::time_length(lubridate::interval(d2, d1), unit)` |
| `$CASENUM` | `dplyr::row_number()`, with a `# NOTE [SPSS]` caveat comment (it only equals SPSS's value when no `SELECT IF`/`FILTER`/`SORT CASES`/`SPLIT FILE` precedes it) |

### Recognised and skipped (no analysis output)

Metadata and I/O commands are recognised and skipped with a comment: `VARIABLE LABELS`,
`VALUE LABELS`, `ADD VALUE LABELS`, `FORMATS`, `TEMPORARY`, `SAVE`, `SAVE OUTFILE`,
`GET FILE`, `GET DATA`, `DATASET`, `WRITE`, `PRINT`, `LIST`, `DISPLAY`, `SET`, `PRESERVE`,
`RESTORE`, `NEW FILE`, `INPUT PROGRAM` / `END INPUT PROGRAM`, `BEGIN DATA` / `END DATA`,
`DEFINE` / `END DEFINE`, `MATCH FILES`, `ADD FILES`, `UPDATE`, `DO REPEAT` / `END REPEAT`,
`RENAME VARIABLES`, `AUTORECODE`, `CASESTOVARS`, `VARSTOCASES`, `GRAPH`,
`GGRAPH`, `WEIGHT`. **Several of these change results in SPSS** — see Limitations.

### Recognised but not converted

`DO IF` / `ELSE IF` / `ELSE` / `END IF`, `MIXED`, `GENLIN`, `CLUSTER`, `NONPAR CORR` and
`PROCESS` are recognised but not translated: the report shows the original syntax under an
"unsupported" note (for `MIXED`, a message that a mixed model must be fitted by hand). Any
other command name is treated the same way: it appears in the report's unsupported section
with its original syntax, never silently dropped.

## Function reference

Every function has a help page (`?parse_sps`).

| Function | What it does |
|---|---|
| `parse_sps(sps_path)` | Reads a `.sps` file and returns a list of parsed commands. Each has `raw` (the command text), `command_type` (e.g. `"T-TEST"`), `subcommands`, `variables`, `options`, and — where relevant — the active `filter_var` and `dataset_key`. |
| `parse_sav(sav_path)` | Reads a `.sav` with `haven::read_sav(user_na = TRUE)`. Returns `data`, `metadata` (a data frame with `name`, `label`, `type`, `format`, `n_missing`), `value_labels`, `n_obs`, `n_vars` and `path`. |
| `convert_all_commands(parsed_commands, sav_info, all_var_names = NULL)` | Converts every parsed command. Returns one list per command with `r_code`, `packages`, `analysis_type`, and when applicable `is_transformation`, `skip`, `note`, `unsupported`, `error`. Pass `all_var_names` (the union of names across several `.sav` files) when `TO` ranges span datasets. |
| `convert_spss_to_r(parsed_command, sav_info, all_var_names = NULL)` | Converts a single parsed command (same return shape). A converter error is caught and returned in `error` rather than thrown. |
| `convert_spss_expression(expr)` | Translates one SPSS expression string to an R expression string (see the Expressions table). |
| `expand_spss_variables(parsed_command, sav_info, all_var_names = NULL)` | Expands `var1 TO var5` ranges in a parsed command against the dataset's column order. A range it cannot resolve is recorded so the command is reported as "variable range could not be expanded" instead of running on a literal `TO`. `convert_all_commands()` already calls this. |
| `generate_rmd(sav_data, sav_path, parsed_syntax, converted_code, output_dir, options = list(), base_name = NULL, conversion_notes = list(), secondary_sav_files = character())` | Writes `<base_name>.Rmd` into `output_dir` and returns a list with `rmd_path` and `data_path` (the path a companion `.rds` copy of the data would have; `generate_rmd()` itself does not write it). `base_name` defaults to the `.sav` file name. `options$include_original` (default `TRUE`) keeps the SPSS syntax beside each result; `options$include_effect_sizes` and `options$table_style` are accepted but currently have no effect. `conversion_notes` are listed in a "Conversion Notes" section. `secondary_sav_files` are extra `.sav` files whose new columns are joined onto the primary data by row position, only when the row counts match; if the files share an ID-like column (`ID`, `CASE`, `SUBJECT`, `PARTICIPANT`, ...) or any other column, its values must agree row-for-row or the merge is skipped with a note, and a merge with no shared column is made with a note stating the row-order assumption. If `sav_data` is `NULL`, the report explains that no dataset was paired. |
| `generate_data_load_code(sav_info, new_path = "data.sav")` | Returns the R code that loads the `.sav` with `haven::read_sav()`. |
| `build_alias_map(parsed)` | Collects every variable name the syntax references (upper-cased, unique), including names from `RECODE ... INTO`, `VARIABLE LABELS` and `RENAME VARIABLES`. |
| `resolve_truncated_name(name, sav_vars, alias_map = character())` | Maps a possibly 8-character-truncated legacy name to the full `.sav` name: exact case-insensitive match first, then a unique 8-character-prefix match; an ambiguous or unmatched name is returned unchanged. |

## Output

The generated `.Rmd` knits to a single self-contained HTML file (`html_document` with a
floating table of contents, folded code and an inline stylesheet). In order it contains: a
setup chunk, embedded helper functions (so knitting needs no `spss2rmarkdown` at render
time), a data-loading section, the transformations, one section per analysis (SPSS syntax,
then results rendered as HTML tables), an unsupported-commands section, the conversion notes,
and `sessionInfo()`.

## Configuration

| Environment variable | Default | Effect |
|---|---|---|
| `SPSS_TRANSFORMS_PER_CHUNK` | `50` | How many consecutive transformation commands are grouped into one knitr chunk in the generated `.Rmd`. Larger groups knit faster; smaller groups isolate a failing transformation more precisely. Values below 1 or non-numbers fall back to 50. |

No `options()` are read.

## Limitations and failure modes

- **Check every number against the SPSS output before relying on it.** The converter is
  deterministic and tested against SPSS output, but a translation can still differ from SPSS
  for syntax it has not been tested on.
- **`WEIGHT` is skipped**, so a weighted SPSS analysis is run unweighted. `MATCH FILES`,
  `ADD FILES`, `UPDATE`, `AUTORECODE`, `RENAME VARIABLES`, `DO REPEAT`, `CASESTOVARS`,
  `VARSTOCASES` and `TEMPORARY` are also skipped; a script that depends on them will analyse
  different data than SPSS did, or fail when it references a variable they would have created.
- **`DO IF` blocks are not converted** — transformations inside them are left for manual
  conversion.
- **`QUICK CLUSTER`** standardises the variables and runs `kmeans()` with 25 random starts
  (`set.seed(42)`); SPSS's k-means uses different starting centres and unstandardised data by
  default, so cluster solutions can differ.
- **`MOD(x, n)` is translated incorrectly** in the current version (the generated R does not
  parse), so a command using it fails at knit time with a visible error.
- **Expression functions outside the table above** (for example `SD`, `VARIANCE`, `MEDIAN`,
  `CONCAT`, `SUBSTR`, `UPCASE`, `LTRIM`, `LENGTH`, `NUMBER`, `STRING`, `INDEX`, `REPLACE`,
  `LAG`, `XDATE.*`, `CDF.*`, `RV.*`) are passed through unchanged, so the generated code stops
  at knit time with "could not find function" for that command.
- `$DATE`, `$TIME`, `$JDATE`, `$LENGTH`, `$WIDTH` are not translated.
- SPSS output that is not a statistical table (charts from `GRAPH`/`GGRAPH`, pivot-table
  formatting) is not reproduced.

## Keeping this README honest

`tools/check_docs_coverage.R` derives the public surface from the package source (every
`export()` in `NAMESPACE`, every environment variable and option the code reads, and — via
`tools/docs_surface_extra.R` — every SPSS command name the parser recognises, the converter
dispatches on, or the converter skips) and fails if any of it is missing from this README, if `DESCRIPTION`, `NEWS.md` and `CITATION.cff`
disagree on the version, or if the Quickstart does not run:

```sh
Rscript tools/check_docs_coverage.R            # from the package root
Rscript tools/check_docs_coverage.R --no-run   # skip executing the Quickstart
```

`tests/testthat/test-docs-coverage.R` pins it both ways when the tests run from a source
checkout (`testthat::test_local()`).

## How to cite

See [`CITATION.cff`](CITATION.cff):

> Feldman, G. (2026). *spss2rmarkdown: Convert SPSS syntax files to reproducible R Markdown
> reports* (Version 0.3.0) [R package]. https://github.com/giladfeldman/spss2rmarkdown

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md). Issues: <https://github.com/giladfeldman/spss2rmarkdown/issues>.

## License

MIT — see [`LICENSE.md`](LICENSE.md).
