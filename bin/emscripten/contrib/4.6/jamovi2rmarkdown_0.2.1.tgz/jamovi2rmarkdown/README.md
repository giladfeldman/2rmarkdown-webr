# jamovi2rmarkdown

Convert jamovi `.omv` analysis files into reproducible R Markdown reports.

A jamovi file stores the data **and** the R syntax of every analysis (jamovi's analyses are
the [`jmv`](https://cran.r-project.org/package=jmv) R package under the hood). This package
reads both out of the `.omv`, repairs the stored calls so they run against the installed
packages, rebuilds jamovi's computed and filter columns, and writes an `.Rmd` that re-runs
every analysis in R. Knitting it lets anyone check a jamovi analysis without jamovi.

Part of a family of converters with a shared design: `spss2rmarkdown`, `jasp2rmarkdown`,
`stata2rmarkdown` and the shared-core package `stat2rmarkdown` (all at
<https://github.com/giladfeldman>).

Version 0.2.1 · MIT licence · R >= 4.1.0

**Principle: the converter converts the analysis, it does not repair the author's choices.** An
analysis the author never finished configuring in jamovi is not completed with guessed
settings: see Limitations.

## Installation

```r
# install.packages("remotes")
remotes::install_github("giladfeldman/jamovi2rmarkdown")
```

Imports: `jsonlite`, `glue`, `stringr`, `rmarkdown`, `fs`, `logger`, `zip`. You also need:

```r
install.packages(c("jmvReadWrite", "RProtoBuf", "jmv"))
```

- **`jmvReadWrite`** reads the `.omv` (required by `parse_omv()`).
- **`RProtoBuf`** decodes the stored analysis definitions. **Without it no analyses are
  extracted** — the report contains the data but no results (a console message says so).
- **`jmv`** runs the analyses when the report is knitted. Analyses from other jamovi modules
  (for example `gamlj`) need that module's R package too; if it is missing, that analysis is
  replaced by a "module unavailable" note.

## Quickstart

The package ships a small jamovi file (`AlbumSales.omv`). Convert it and knit the report:

```r
library(jamovi2rmarkdown)

omv <- system.file("testdata", "AlbumSales.omv", package = "jamovi2rmarkdown")
out_dir <- file.path(tempdir(), "jamovi2r-demo")

res <- convert_omv_to_rmd(omv, output_dir = out_dir)
cat(res$n_analyses, "analyses ->", res$rmd_path, "\n")

if (rmarkdown::pandoc_available()) {
  html <- rmarkdown::render(res$rmd_path, quiet = TRUE)
  cat("Report:", html, "\n")
}
```

## How it works

1. **Parse** (`parse_omv()`): read the data and the stored jmv syntax with `jmvReadWrite`
   (a lenient reader first, then `jmvReadWrite::read_omv()`), and save the data
   as `<name>_data.rds` and `<name>_data.csv`.
2. **Extract** (`extract_analyses()`): split the syntax into one block per analysis.
3. **Repair** (internal): quote variable names with special characters; drop arguments the
   installed version of a function no longer accepts; map renamed module functions (e.g.
   `gamlj::gamljGLM` to `gamlj::gamljGlm`); flag analyses the author left unconfigured; wrap
   each call so one failure does not stop the report.
4. **Reconstruct data** (internal): translate jamovi computed/recoded-variable formulas to
   `dplyr::mutate()` code, preserve labelled-factor codes, and build a `data_filtered` copy
   for analyses that ran under a jamovi row filter.
5. **Generate** (`generate_rmd()`): write the `.Rmd` with a codebook, one section per analysis
   (results as HTML tables), and `sessionInfo()`.

### What is converted

- **Any analysis whose syntax jamovi stored** — the converter reuses jamovi's own call, so
  every `jmv` analysis is covered (`jmv::descriptives`, `jmv::ttestIS`, `jmv::ttestPS`,
  `jmv::ttestOneS`, `jmv::ANOVA`, `jmv::ancova`, `jmv::anovaRM`, `jmv::mancova`,
  `jmv::corrMatrix`, `jmv::linReg`, `jmv::logRegBin`, `jmv::contTables`, `jmv::reliability`,
  `jmv::pca`, `jmv::efa`, and the rest) as long as the installed `jmv` accepts the call.
- **Add-on module analyses** run if the module's R package is installed. One exception is
  built in: the TOSTER one-sample equivalence test (`TOSTER::dataTOSTone`) is reproduced in
  base R, with the equivalence bounds read from the file, so it needs no extra package (TOST
  method: Lakens, 2017, <https://doi.org/10.1177/1948550617697177>).
- **Computed and recoded variables.** Formula functions translated: arithmetic and comparison
  operators, `and`/`or`, `MEAN`, `SUM`, `MIN`, `MAX` (strict: a missing input gives a missing
  result, as in jamovi), `ABS`, `SQRT`, `LN`, `LOG10`, `EXP`, `Z`, `IF`, `IFMISS`, `RECODE`,
  `ROW()`. Every column reference is coerced to its underlying numeric value, as jamovi does.
- **Row filters** set in jamovi: analyses that jamovi ran on filtered data use the filtered
  copy; analyses declared before the filter use the full data.

## Function reference

Every function has a help page (`?convert_omv_to_rmd`).

| Function | What it does |
|---|---|
| `convert_omv_to_rmd(omv_path, output_dir = ".", include_metadata = TRUE)` | The whole pipeline: parse, extract, repair, reconstruct data, write the `.Rmd`. Creates `output_dir` if needed. Returns (invisibly) `rmd_path`, `data_path` (the `.rds`) and `n_analyses`. With `include_metadata = TRUE` the report opens with a codebook and the jamovi version. Does not knit. |
| `process_single_file(file_path, file_name, progress_callback = NULL, session_output_dir = NULL, skip_render = FALSE)` | The production pipeline used by the conversion service: converts **and knits** into a new `<timestamp>-<name>` folder under `session_output_dir` (default `./output`). `progress_callback(stage, percent, message)` receives progress updates. Returns `success`, `output_dir`, `base_name`, `error_message` (with local paths redacted). Never throws: a failure comes back as `success = FALSE`. |
| `parse_omv(path, outdir, base_name = NULL)` | Reads the `.omv`, writes `<base_name>_data.rds` and `<base_name>_data.csv` into `outdir`, and returns `data`, `attrs`, `syntax` (character vector of jmv calls), `html`, `base_name` and `method` (`"enhanced"`, `"standard"` or `"enhanced-no-syntax"`). |
| `extract_analyses(syntax)` | Splits the syntax into a list of analysis blocks, each with `title` and `code`. |
| `extract_omv_metadata(omv_path, output_dir = NULL)` | Reads the `.omv` archive directly and returns `version_info`, `variable_metadata`, `value_labels`, `computed_variables`, `transforms` and `plots` (plot files are extracted only when `output_dir` is given). |
| `generate_rmd(outdir, meta, data_code, analyses, precomputed_outputs = NULL)` | Writes `<meta$base_name>.Rmd` into `outdir` and returns its path invisibly. `meta` is a list with `title`, `base_name` and optionally `version_info` and `codebook`; `data_code` is the R code that loads the data; `analyses` comes from `extract_analyses()`. `precomputed_outputs`, when given, embeds static results instead of live chunks. |

For the lower-level steps, `convert_omv_to_rmd()` is the reference for how the pieces fit
together; the repair and data-reconstruction steps are internal.

## Output

`convert_omv_to_rmd()` writes into `output_dir`: `<name>.Rmd`, `<name>_data.rds` (what the
report loads) and `<name>_data.csv` (the raw data, for use outside R), plus any plots stored
in the file when metadata extraction is on. The `.Rmd` knits to a single self-contained HTML
file with a floating table of contents and folded code.

## Configuration

| Environment variable | Effect |
|---|---|
| `HOME` | Read only by `process_single_file()`, to replace the home-directory path with `<home>` in error messages it returns. |

No `options()` are read.

## Limitations and failure modes

- **Check every number against the jamovi output before relying on it.** The converter re-runs
  jamovi's own calls, but results can differ if the installed `jmv` version computes something
  differently from the jamovi version that produced the file.
- **`RProtoBuf` is required for analyses** (see Installation); without it the report has data
  but no results.
- **Formula functions outside the list above** are lower-cased and passed through unchanged.
  Most then fail at knit time with "could not find function" for that column, but a few names
  coincide with R functions that behave differently from jamovi's (for example `SAMPLE`,
  `FILTER`, `SCALE`, `OFFSET`), so a computed column that uses them must be checked by hand.
- **Unfinished analyses are not run.** An analysis with no variables assigned is left out of
  the report (the conversion prints how many were skipped); one with a required option left
  blank is reported as incomplete.
- jamovi's own rendering (its table formatting and footnotes) is not reproduced; results
  appear as the R code produces them.

## Keeping this README honest

`tools/check_docs_coverage.R` derives the public surface from the package source (every
`export()` in `NAMESPACE`, every environment variable and option the code reads) and fails if
any of it is missing from this README, if `DESCRIPTION`, `NEWS.md` and `CITATION.cff`
disagree on the version, or if the Quickstart does not run:

```sh
Rscript tools/check_docs_coverage.R            # from the package root
Rscript tools/check_docs_coverage.R --no-run   # skip executing the Quickstart
```

`tests/testthat/test-docs-coverage.R` pins it both ways when the tests run from a source
checkout (`testthat::test_local()`).

## How to cite

See [`CITATION.cff`](CITATION.cff):

> Feldman, G. (2026). *jamovi2rmarkdown: Convert jamovi analysis files to reproducible R
> Markdown reports* (Version 0.2.1) [R package]. https://github.com/giladfeldman/jamovi2rmarkdown

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md). Issues: <https://github.com/giladfeldman/jamovi2rmarkdown/issues>.

## License

MIT — see [`LICENSE.md`](LICENSE.md).
