# jasp2rmarkdown

Convert JASP `.jasp` analysis files into reproducible R Markdown reports.

A `.jasp` file is a ZIP archive holding the dataset and the settings of every analysis. This
package reads both, translates each analysis into R code built on open R packages (`jmv`,
`BayesFactor`, `metafor`, `weightr`, `RoBMA`, `psych`, `qgraph`, `lavaan`, ...), and writes an
`.Rmd` that re-runs the analyses. JASP's own analysis packages are **not** called: they only run
inside JASP Desktop, so every result in the report is recomputed by the package named in the
table below.

Part of a family of converters with a shared design: `spss2rmarkdown`, `jamovi2rmarkdown`,
`stata2rmarkdown` and the shared-core package `stat2rmarkdown` (all at
<https://github.com/giladfeldman>).

Version 0.3.0 · MIT licence · R >= 4.1.0

## Installation

```r
# install.packages("remotes")
remotes::install_github("giladfeldman/jasp2rmarkdown")
```

Imports: `jsonlite`, `DBI`, `RSQLite`, `glue`, `stringr`. To **knit** the reports you also need
`rmarkdown` (and pandoc) and `jmv`, plus whichever packages the analyses in your file use:

```r
install.packages(c("rmarkdown", "jmv", "BayesFactor", "metafor", "psych"))
# as needed: weightr, RoBMA, metaBMA, bayesmeta, bayestestR, lavaan, bain, qgraph, lme4
```

## Quickstart

The package ships a small JASP file. Convert it and knit the report — note that the generated
`.Rmd` reads its data from a `data.csv` in the same folder, which you write yourself:

```r
library(jasp2rmarkdown)

jasp <- system.file("testdata", "interrater_shrout_fleiss.jasp", package = "jasp2rmarkdown")
out_dir <- file.path(tempdir(), "jasp2r-demo")
dir.create(out_dir, showWarnings = FALSE)

extracted <- extract_jasp(jasp)
analyses  <- read_analyses(extracted)
data      <- read_jasp_data(extracted)
cat(length(analyses), "analyses:", vapply(analyses, `[[`, "", "name"), "\n")
cat(map_analysis(analyses[[1]]), "\n")           # the R code for the first analysis

write.csv(data, file.path(out_dir, "data.csv"), row.names = FALSE)
rmd_path <- file.path(out_dir, "report.Rmd")
writeLines(generate_rmd(jasp), rmd_path)

if (rmarkdown::pandoc_available()) {
  html <- rmarkdown::render(rmd_path, quiet = TRUE)
  cat("Report:", html, "\n")
}
```

## Function reference

Every function has a help page (`?generate_rmd`).

| Function | What it does |
|---|---|
| `generate_rmd(jasp_path)` | The whole pipeline: extracts the archive, reads the data and analyses, maps each analysis, and returns the `.Rmd` as a **character vector of lines** (write it with `writeLines()`). The report loads `data.csv` from its own folder. Only the packages the file's analyses need are loaded in the setup chunk. |
| `extract_jasp(jasp_path)` | Unzips the `.jasp` into a new temporary directory and returns its path. |
| `read_analyses(extract_dir)` | Parses the archive's analysis definitions into a list of analysis objects, each with `name` (JASP's internal analysis name, e.g. `"TTestIndependentSamples"`), `title` and `options`. |
| `read_jasp_data(extract_dir)` | Returns the dataset as a data frame, trying `internal.sqlite` (current JASP), then `xdata.json` (older JASP), then a `data.csv` in the archive; `NULL` if none yields data. |
| `map_analysis(analysis_obj, dataset_name = "data")` | Returns the R code (one string) for one analysis object. `dataset_name` is the variable name the code uses for the data. An unmapped analysis, or one whose mapping fails, returns a comment saying so plus a `str()` of the data — never code that pretends to be the analysis. |

## Supported JASP analyses

The mapper recognises 67 JASP analysis names. Matching is exact, then case-insensitive, then
with any `module::` prefix removed. They fall in three groups — **check which group your
analysis is in before relying on a number.**

### Recomputed with an equivalent method

| JASP analysis | R engine in the generated code |
|---|---|
| `Descriptives` | `jmv::descriptives` |
| `TTestIndependentSamples`, `TTestPairedSamples`, `TTestOneSample` | `jmv::ttestIS`, `jmv::ttestPS`, `jmv::ttestOneS` |
| `TTestBayesianIndependentSamples`, `TTestBayesianPairedSamples`, `TTestBayesianOneSample` | the same `jmv` functions with `bf = TRUE` and the file's prior width |
| `Anova`, `AnovaRepeatedMeasures`, `Ancova`, `Manova` | `jmv::ANOVA`, `jmv::anovaRM`, `jmv::ancova`, `jmv::mancova` |
| `ContingencyTables`, `Correlation` | `jmv::contTables`, `jmv::corrMatrix` |
| `RegressionLinear`, `RegressionLogistic`, `RegressionLogLinear` | `jmv::linReg`, `jmv::logRegBin`, `jmv::logLinear` |
| `BinomialTest`, `BinomialTestBayesian`, `MultinomialTest` | `jmv::propTest2` (with `bf = TRUE` for the Bayesian test), `jmv::propTestN` |
| `exploratoryFactorAnalysis`, `principalComponentAnalysis`, `confirmatoryFactorAnalysis` | `jmv::efa`, `jmv::pca`, `jmv::cfa` (CFA only when the file specifies the factors) |
| `unidimensionalReliabilityFrequentist` | `jmv::reliability` |
| `CorrelationBayesian`, `AnovaBayesian`, `AnovaRepeatedMeasuresBayesian`, `RegressionLinearBayesian`, `AncovaBayesian`, `ContingencyTablesBayesian`, `RegressionLogLinearBayesian` | `BayesFactor` (`correlationBF`, `anovaBF` with `bayestestR::bf_inclusion` for repeated measures, `regressionBF`, `lmBF`, `contingencyTableBF`) |
| `SummaryStatsTTestBayesianOneSample`, `SummaryStatsTTestBayesianPairedSamples`, `SummaryStatsTTestBayesianIndependentSamples`, `SummaryStatsBinomialTestBayesian` | `BayesFactor::ttest.tstat`, `BayesFactor::proportionBF` |
| `ClassicalMetaAnalysis`, `FunnelPlot`, `PetPeese`, `EffectSizeComputation` | `metafor` (`rma`, `funnel`, `regtest`, `escalc`); PET-PEESE as weighted `lm()` |
| `SelectionModels` | `weightr::weightfunct`, following JASP's conventions (Cohen's *d* scale when JASP transforms correlations, observed-information standard errors, joined p-value intervals); a fit whose optimiser did not converge is refused rather than printed |
| `BayesianMetaAnalysis` | `metaBMA::meta_bma` (model-averaged) with `bayesmeta::bayesmeta` |
| `RobustBayesianMetaAnalysis` | `RoBMA::RoBMA`; when it cannot be fitted the report says so and names the `metaBMA` substitute it shows instead |
| `intraclassCorrelation`, `standardErrorOfMeasurement` | `psych::ICC`, `psych::alpha` |
| `NetworkAnalysis` | `qgraph::EBICglasso`, `qgraph::centrality_auto` |
| `BainSemBayesian` | `bain::bain` on a `lavaan` fit |

### Approximations — a different method from JASP's

| JASP analysis | What the report runs instead |
|---|---|
| `BainTTestBayesianIndependentSamples`, `BainTTestBayesianOneSample`, `BainTTestBayesianPairedSamples`, `BainAnovaBayesian`, `BainAncovaBayesian`, `BainRegressionLinearBayesian` | the default-prior `BayesFactor`/`jmv` Bayes factor, not `bain`'s informative-hypothesis Bayes factor |
| `unidimensionalReliabilityBayesian` | frequentist `jmv::reliability` (alpha, omega) and `psych::omega` |
| `ClassicalMetaAnalysisMultilevelMultivariate` | the univariate `ClassicalMetaAnalysis` mapping |
| `ClassicProcess`, `BayesianProcess` | a single-mediator `lavaan::sem` model built from the first covariate and the first mediator |

### Placeholders — no result is computed

`SEM`, `LatentGrowthCurve`, `MixedModelsLMM`, `MixedModelsGLMM`, `msaAttribute`, `msaGaugeRR`,
`msaGaugeRRnonrep`, `doeAnalysis`, `variablesChartsIndividuals`, `auditBayesianEvaluation`,
`auditBayesianWorkflow` produce a commented template and a message naming the package to use,
not an analysis. `jaspPlotBuilder` produces a scatter plot of the first two data columns, not
the plot defined in JASP. Any other analysis name gets the "not yet mapped" comment described
under `map_analysis()`.

## Output

`generate_rmd()` returns the lines of an `.Rmd` that knits to a single self-contained HTML
file (floating table of contents, folded code, inline stylesheet). It contains a setup chunk,
embedded table-rendering helpers (so knitting needs no `jasp2rmarkdown`), a data section that
reads `data.csv` and converts columns for `jmv`, one section per analysis with its R code and
results as HTML tables, and `sessionInfo()`.

## Configuration

The package reads no environment variables and no `options()`.

## Limitations and failure modes

- **Check every number against the JASP output before relying on it**, and first check which
  of the three groups above the analysis falls in. Only the first group is intended to
  reproduce JASP; approximations and placeholders do not.
- **The data file is not written for you**: knit fails with "cannot open file 'data.csv'"
  unless you write the data next to the `.Rmd` (see the Quickstart).
- JASP options the mapper does not read are ignored, so an analysis configured with an unusual
  option can run with `jmv`'s default for that option instead.
- JASP's own plots and table formatting are not reproduced.

## Keeping this README honest

`tools/check_docs_coverage.R` derives the public surface from the package source (every
`export()` in `NAMESPACE`, every environment variable and option the code reads, and — via
`tools/docs_surface_extra.R` — every JASP analysis name the mapper recognises) and fails if
any of it is missing from this README, if `DESCRIPTION`, `NEWS.md` and `CITATION.cff`
disagree on the version, or if the Quickstart does not run:

```sh
Rscript tools/check_docs_coverage.R            # from the package root
Rscript tools/check_docs_coverage.R --no-run   # skip executing the Quickstart
```

`tests/testthat/test-docs-coverage.R` pins it both ways when the tests run from a source
checkout (`testthat::test_local()`).

## How to cite

See [`CITATION.cff`](CITATION.cff):

> Feldman, G. (2026). *jasp2rmarkdown: Convert JASP analysis files to reproducible R Markdown
> reports* (Version 0.3.0) [R package]. https://github.com/giladfeldman/jasp2rmarkdown

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md). Issues: <https://github.com/giladfeldman/jasp2rmarkdown/issues>.

## License

MIT — see [`LICENSE.md`](LICENSE.md).
